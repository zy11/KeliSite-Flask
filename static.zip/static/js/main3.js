// JavaScript Document

	var secondChart=echarts.init(document.getElementById('data'));
	var option = {
	color:['#cd5658','#60b3df'],
	text:{

		textStyle:{
			fontsize:'18',
			color:'#000'},
			},
    tooltip : {
        trigger: 'item',
        formatter: "{a} <br/>{b} : {c} ({d}%)"
		
    },
    legend: {
        orient : 'horizontal',
        x : 'left',
		y:'center',
		textStyle:{
			color:'#000'},
        data:['inline','offline']

    },
    toolbox: 
	{
        show : true,
		
        feature : {
            mark : {show: true},
            dataView : {show: true, readOnly: false},
            magicType : {
                show: true, 
                type: ['pie', 'funnel'],
                option: {
                    funnel: {
                        x: '25%',
                        width: '50%',
                        funnelAlign: 'center',
                        max: 1548
                    }
                }
				
            },
			
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    calculable : true,
    series : [
        {
            name:'访问来源',
            type:'pie',
            radius : ['55%', '70%'],
            itemStyle : {
                normal : {
                    label : {
                        show : true
                    },
                    labelLine : {
                        show : true
                    }
                },
                emphasis : {
                    label : {
                        show : true,
                        position : 'center',
                        textStyle : {
                            fontSize : '15',
                            fontWeight : 'bold'
                        }
                    }
                }
            },
            data:[
                {value:1200, name:'offline'},
                {value:1500, name:'inline'}

            ]
        }
    ]
};
       secondChart.setOption(option);   
